//
//  PNDBRunner.m
//  OCTest
//
//  Created by apple on 2018/3/19.
//  Copyright © 2018年 Zeposhe. All rights reserved.
//

#import "PNDBRunner.h"
#import <GYDataCenter/FMDatabaseQueue+Async.h>
#import <GYDataCenter/GYDCUtilities.h>
#import <GYDataCenter/GYModelObjectProtocol.h>
#import <GYDataCenter/GYReflection.h>
#import <objc/runtime.h>
#import <UIKit/UIKit.h>

@interface PNDatabaseInfo: NSObject

@property (nonatomic, strong) FMDatabaseQueue *databaseQueue;
@property (nonatomic, strong) NSMutableSet *updatedTables;
@property (nonatomic, strong) dispatch_source_t timer;
@property (nonatomic, assign) BOOL needCommitTransaction;
@property (nonatomic, assign) NSInteger writeCount;

@end


@implementation PNDatabaseInfo

- (instancetype)init {
    if (self = [super init]) {
        _updatedTables = [[NSMutableSet alloc] init];
    }
    return self;
}

@end

@interface PNDBRunner() {
    NSMutableDictionary *_databaseInfos;
}

@property NSMutableDictionary *writeCounts;

@end

@implementation PNDBRunner

+ (NSString *)pathForAnalyzeStatistics {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths firstObject];
    return [documentsDirectory stringByAppendingPathComponent:@"GYDataCenterAnalyzeStatistics"];
}


+ (instancetype)sharedWithCacheDelegate:(id<PNDBCache>)delegate {
    static PNDBRunner *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[PNDBRunner alloc] initWithCacheDelegate:delegate];
        NSData *data = [NSData dataWithContentsOfFile:[self pathForAnalyzeStatistics]];
        if (data.length) {
            shared.writeCounts = [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListMutableContainers format:nil error:nil];
        } else {
            shared.writeCounts = [[NSMutableDictionary alloc] init];
        }
    });
    shared.cacheDelegate = delegate;
    return shared;
}

- (instancetype)initWithCacheDelegate:(id<PNDBCache>)delegate {
    if (self = [super init]) {
        _cacheDelegate = delegate;
        _databaseInfos = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (NSArray *)objectOfClass:(Class<GYModelObjectProtocol>)modelClass properties:(NSArray *)properties where:(NSString *)where arguments:(NSArray *)arguments {
    NSMutableArray *objects = [[NSMutableArray alloc] init];
    NSString *columnSql = @"*";
    if ([modelClass fts] && [modelClass primaryKey] && !properties) {
        properties = [GYDCUtilities persistentPropertiesForClass:modelClass];
    }
    if (properties.count) {

    }
    return objects;
}

- (NSArray *)objectsOfClass:(Class<GYModelObjectProtocol>)leftClass properties:(NSArray *)leftProperties class:(Class<GYModelObjectProtocol>)rightClass properties:(NSArray *)rightProperties joinCondition:(NSString *)joinCondition where:(NSString *)where arguments:(NSArray *)arguments {
    return nil;
}

- (NSString *)columnSqlForClass:(Class<GYModelObjectProtocol>)modelClass
                     properties:(NSArray *)properties
                     withPrifix:(BOOL)withPrefix {
    if (!properties) {
        properties = [GYDCUtilities persistentPropertiesForClass:modelClass];
    }
    NSMutableString *columnSql = [[NSMutableString alloc] init];
    NSString *tableName = [modelClass tableName];
    for (NSUInteger i = 0; i < properties.count; ++i) {
        NSString *property = properties[i];
        NSAssert([GYDCUtilities persistentPropertiesForClass:modelClass], @"Property %@ is not persistent", property);
        NSString *column = [GYDCUtilities columnForClass:modelClass property:property];
        if (i) {
            if (withPrefix) {
                [columnSql appendFormat:@",%@.%@",tableName,column];
            } else {
                [columnSql appendFormat:@",%@", column];
            }
        } else {
            if (withPrefix) {
                [columnSql appendFormat:@"%@.%@", tableName, column];
            } else {
                [columnSql appendFormat:@"%@", column];
            }
        }
    }
    return columnSql;
}

- (id)valueForClass:(Class<GYModelObjectProtocol>)modelClass
           property:(NSString *)property
          resultSet:(FMResultSet *)resultSet
              index:(int)index {
    GYPropertyType propertyType = [[[modelClass propertyTypes] objectForKey:property] unsignedIntegerValue];
    Class propertyClass;
    if (propertyType == GYPropertyTypeRelationship) {
        propertyClass = [[modelClass propertyClasses] objectForKey:property];
        propertyType = [[[propertyClass propertyTypes] objectForKey:property] unsignedIntegerValue];
    }
    id value = nil;
    return value;
}

- (id)objectOfClass:(Class<GYModelObjectProtocol>)modelClass
             result:(FMResultSet *)resultSet
              range:(NSRange)range
         properties:(NSMutableArray *)properties {
    id object = nil;
    for (NSInteger i = range.location; i < range.location + range.length; ++i) {
        NSInteger index = i - range.location;
        if (index >= properties.count) {
            NSString *column = [resultSet columnNameForIndex:index];
            [properties addObject:[GYDCUtilities propertyForClass:modelClass column:column]];
        }
        NSString *property = [properties objectAtIndex:index];
        if (index == 0 && [property isEqualToString:[modelClass primaryKey]]) {

        }
    }
    return object;
}

@end
