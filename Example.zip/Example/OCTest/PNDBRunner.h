//
//  PNDBRunner.h
//  OCTest
//
//  Created by apple on 2018/3/19.
//  Copyright © 2018年 Zeposhe. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PNSQLJoinType) {
    PNSQLJoinTypeInner,
    PNSQLJoinTypeLeft,
    PNSQLJoinTypeCross
};

@protocol GYModelObjectProtocol;
@protocol PNDBCache <NSObject>

- (id)objectOfClass:(Class<GYModelObjectProtocol>)modelClass id:(id)objectId;
- (void)cacheObject:(id<GYModelObjectProtocol>)modelObject;

@end
@interface PNDBRunner : NSObject

@property (nonatomic, weak) id<PNDBCache> cacheDelegate;

+ (instancetype)sharedWithCacheDelegate:(id<PNDBCache>)delegate;

- (NSArray *)objectOfClass:(Class<GYModelObjectProtocol>)modelClass
                properties:(NSArray *)properties
                     where:(NSString *)where
                 arguments:(NSArray *)arguments;
- (NSArray *)objectsOfClass:(Class<GYModelObjectProtocol>)leftClass
                 properties:(NSArray *)leftProperties
                      class:(Class<GYModelObjectProtocol>)rightClass
                 properties:(NSArray *)rightProperties
              joinCondition:(NSString *)joinCondition
                      where:(NSString *)where
                  arguments:(NSArray *)arguments;

- (NSArray *)idsOfClass:(Class<GYModelObjectProtocol>)modelClass
                  where:(NSString *)where
              arguments:(NSArray *)arguments;

- (NSNumber *)aggregateOfClass:(Class<GYModelObjectProtocol>)modelClass
                      function:(NSString *)function
                         where:(NSString *)where
                     arguments:(NSArray *)arguments;

- (void)setObject:(id<GYModelObjectProtocol>)object;
- (void)deleteClass:(Class<GYModelObjectProtocol>)modelClass
              where:(NSString *)where
          arguments:(NSArray *)arguments;
- (void)undateClass:(Class<GYModelObjectProtocol>)modelClass
                set:(NSDictionary *)set
              where:(NSString *)where
          arguments:(NSArray *)arguments;
- (void)beginTransactionForDbName:(NSString *)dbName;
- (void)commitTransactionFOrDbName:(NSString *)dbName;

- (void)vacuumAllDBs;

- (void)synchronizeDB:(NSString *)dbName;

@end
